[
  {
    "name": "推荐",
    "list": [
      {
        "name": "🍁凯少爷🍁",
        "url": " ",
        "icon": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "version": "🍁凯少爷🍁"
      },
      {
        "name": "凯少躺平版",
        "url": "https://d.kstore.dev/download/6375/APP/凯少爷影视躺平版.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "4x版"
      },
      {
        "name": "凯少QQ群",
        "url": " ",
        "icon": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "version": ""
      }
    ]
  },
  {
    "name": "🍁凯少爷🍁下载影视软件",
    "list": [
      {
        "name": "凯少躺平版",
        "url": "https://d.kstore.dev/download/6375/APP/凯少爷影视躺平版.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "4x版"
      },
      {
        "name": "影视仓",
        "url": "https://d.kstore.dev/download/6375/APP/影视仓5.0.46.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "5.0.46版"
      },
      {
        "name": "影视仓V3",
        "url": "https://d.kstore.dev/download/6375/APP/影视仓V3.0.36脱壳解密版.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "3.0.36脱壳解密版"
      },
      {
        "name": "OK影视电视版",
        "url": "https://wp.qiongjing.top/down.php/08cd01ce693f120ff2f47177cc0f6112.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "2.6.6版"
      },
      {
        "name": "OK影视安卓4#2.6.6",
        "url": "https://wp.qiongjing.top/down.php/001b844810ebd2a2d2b32e91ea5c1d89.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "5x2.6.6版"
      },
      {
        "name": "CatBoxTV版",
        "url": "https://wp.qiongjing.top/down.php/282772f7f0061456cd1c4bd5b23ef5c5.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "v20240515_2314版"
      },
      {
        "name": "🍁凯少爷🍁",
        "url": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "icon": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "version": "感谢支持"
      },
      {
        "name": "凯少QQ群",
        "url": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "icon": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "version": ""
      }
    ]
  },
  {
    "name": "🍁凯少爷🍁常用工具",
    "list": [
      {
        "name": "野草助手",
        "url": "https://wp.qiongjing.top/down.php/07a5083732a07bb7c2a89b1ad92ddd4c.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "电视版"
      },
      {
        "name": "甲壳虫ADB助手",
        "url": "http://wb.nxog.top:5244/d/移/软件/软件集合/甲壳虫ADB助手.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "手机版"
      },
      {
        "name": "八爪鱼遥控TV版",
        "url": "http://wb.nxog.top:5244/d/移/软件/软件集合/八爪鱼遥控TV版.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "TV版"
      },
      {
        "name": "八爪鱼遥控手机版",
        "url": "http://wb.nxog.top:5244/d/移/软件/软件集合/八爪鱼遥控手机版.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "手机版"
      },
      {
        "name": "当贝桌面",
        "url": "http://wb.nxog.top:5244/d/移/软件/软件集合/当贝桌面.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "TV版"
      },
      {
        "name": "小白文件管理器TV版",
        "url": "http://wb.nxog.top:5244/d/移/软件/软件集合/小白文件管理器TV版.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "TV版"
      },
      {
        "name": "小米电视助手",
        "url": "http://wb.nxog.top:5244/d/移/软件/软件集合/小米电视助手.apk",
        "icon": "https://tse4-mm.cn.bing.net/th/id/OIP-C.55pjzN1Za9JfzLozG-cJygHaQC?dpr=3&pid=ImgDetMain",
        "version": "手机版版"
      },
      {
        "name": "🍁凯少爷🍁",
        "url": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "icon": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "version": "感谢支持"
      },
      {
        "name": "凯少QQ群",
        "url": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "icon": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "version": ""
      }
    ]
  },
  {
    "name": "🍁凯少爷🍁QQ群",
    "list": [
      {
        "name": "🍁凯少爷🍁",
        "url": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "icon": "https://gitea.moe/857/1/raw/branch/main/res_drawable_redd.png",
        "version": "感谢支持"
      },
      {
        "name": "凯少QQ群",
        "url": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "icon": "https://gitea.moe/857/1/raw/branch/main/qrcode_1735464662215.jpg",
        "version": ""
      }
    ]
  }
]